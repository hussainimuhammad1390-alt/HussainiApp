# Africa Regional Agro

A starter agricultural support application platform with:
- Public home page
- User registration/login/logout
- User dashboard
- Agricultural support application form
- Document upload
- Application status tracking
- Admin login and dashboard
- SQLite database

## Run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env` and change the admin password/secret.
5. Run:
   npm start
6. Open:
   http://localhost:3000

## Admin
Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `.env`.

## Important before public launch
This is a working starter application, not a finished compliance/security audit. Before collecting real applicants' identity or bank information:
- use HTTPS,
- change all demo secrets,
- use a strong production session store,
- add CSRF protection and rate limiting,
- restrict and virus-scan uploads,
- add privacy/consent notices and a retention policy,
- configure backups,
- have the program's legal/eligibility claims reviewed,
- do not imply affiliation with FARA, AfDB, CAAPs, World Bank, or any government agency without authorization.
