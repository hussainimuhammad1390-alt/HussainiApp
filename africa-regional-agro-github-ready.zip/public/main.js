document.getElementById("year")?.append(new Date().getFullYear());
const menu=document.getElementById("menu"), nav=document.querySelector(".nav nav");
menu?.addEventListener("click",()=>nav.classList.toggle("open"));
document.getElementById("contactForm")?.addEventListener("submit",e=>{e.preventDefault();alert("Thank you. Your message has been received.");e.target.reset()});