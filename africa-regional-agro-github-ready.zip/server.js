const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || "development-only-change-me";

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

const db = new Database(path.join(dataDir, "agro.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  state TEXT,
  lga TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  program TEXT NOT NULL,
  farm_name TEXT,
  farm_size TEXT,
  state TEXT,
  lga TEXT,
  experience TEXT,
  reason TEXT NOT NULL,
  support_needed TEXT NOT NULL,
  bank_name TEXT,
  account_name TEXT,
  account_number TEXT,
  document_path TEXT,
  status TEXT NOT NULL DEFAULT 'Pending',
  admin_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@example.com";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeMe123!";
const adminHash = bcrypt.hashSync(adminPassword, 10);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${Date.now()}-${safe}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "application/pdf"];
    cb(null, allowed.includes(file.mimetype));
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, "public")));

function userRequired(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in." });
  next();
}
function adminRequired(req, res, next) {
  if (!req.session.isAdmin) return res.status(401).json({ error: "Admin login required." });
  next();
}

app.post("/api/register", (req, res) => {
  const { fullName, email, phone, password, state, lga } = req.body;
  if (!fullName || !email || !phone || !password) return res.status(400).json({ error: "Please complete all required fields." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });

  try {
    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare(`
      INSERT INTO users (full_name,email,phone,password_hash,state,lga)
      VALUES (?,?,?,?,?,?)
    `).run(fullName.trim(), email.trim().toLowerCase(), phone.trim(), hash, state || "", lga || "");
    req.session.userId = info.lastInsertRowid;
    res.json({ ok: true });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with that email already exists." });
    res.status(500).json({ error: "Registration failed." });
  }
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get((email || "").trim().toLowerCase());
  if (!user || !bcrypt.compareSync(password || "", user.password_hash)) return res.status(401).json({ error: "Invalid email or password." });
  req.session.userId = user.id;
  req.session.isAdmin = false;
  res.json({ ok: true });
});

app.post("/api/admin/login", (req, res) => {
  const { email, password } = req.body;
  if (email?.trim().toLowerCase() === adminEmail.toLowerCase() && bcrypt.compareSync(password || "", adminHash)) {
    req.session.isAdmin = true;
    req.session.userId = null;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: "Invalid admin credentials." });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  if (req.session.isAdmin) return res.json({ admin: true });
  if (!req.session.userId) return res.json({ authenticated: false });
  const user = db.prepare("SELECT id,full_name,email,phone,state,lga,created_at FROM users WHERE id=?").get(req.session.userId);
  res.json({ authenticated: true, user });
});

app.get("/api/my-applications", userRequired, (req, res) => {
  const rows = db.prepare(`
    SELECT id,program,farm_name,farm_size,state,lga,experience,reason,support_needed,
           status,admin_note,created_at
    FROM applications WHERE user_id=? ORDER BY id DESC
  `).all(req.session.userId);
  res.json(rows);
});

app.post("/api/applications", userRequired, upload.single("document"), (req, res) => {
  const {
    program, farmName, farmSize, state, lga, experience,
    reason, supportNeeded, bankName, accountName, accountNumber
  } = req.body;

  if (!program || !reason || !supportNeeded) return res.status(400).json({ error: "Program, reason and support needed are required." });

  const documentPath = req.file ? `/uploads/${req.file.filename}` : null;
  const info = db.prepare(`
    INSERT INTO applications
    (user_id,program,farm_name,farm_size,state,lga,experience,reason,support_needed,
     bank_name,account_name,account_number,document_path)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    req.session.userId, program, farmName || "", farmSize || "", state || "",
    lga || "", experience || "", reason, supportNeeded, bankName || "",
    accountName || "", accountNumber || "", documentPath
  );
  res.json({ ok: true, applicationId: info.lastInsertRowid });
});

app.get("/api/admin/applications", adminRequired, (req, res) => {
  const rows = db.prepare(`
    SELECT a.*, u.full_name, u.email, u.phone
    FROM applications a JOIN users u ON u.id=a.user_id
    ORDER BY a.id DESC
  `).all();
  res.json(rows);
});

app.patch("/api/admin/applications/:id", adminRequired, (req, res) => {
  const { status, adminNote } = req.body;
  const allowed = ["Pending", "Under Review", "Approved", "Rejected"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status." });
  db.prepare("UPDATE applications SET status=?, admin_note=? WHERE id=?")
    .run(status, adminNote || "", req.params.id);
  res.json({ ok: true });
});

app.get("/api/admin/stats", adminRequired, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) c FROM users").get().c;
  const applications = db.prepare("SELECT COUNT(*) c FROM applications").get().c;
  const pending = db.prepare("SELECT COUNT(*) c FROM applications WHERE status IN ('Pending','Under Review')").get().c;
  const approved = db.prepare("SELECT COUNT(*) c FROM applications WHERE status='Approved'").get().c;
  res.json({ users, applications, pending, approved });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Africa Regional Agro running at http://localhost:${PORT}`));
