package com.hussaini.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF0D47A1)
private val Blue2 = Color(0xFF1976D2)
private val Bg = Color(0xFFF5F7FA)
private val Green = Color(0xFF2E7D32)
private val Red = Color(0xFFD32F2F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HussainiApp() }
    }
}

@Composable
fun HussainiApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Blue2, background = Bg)
    ) {
        var page by remember { mutableStateOf("login") }
        when (page) {
            "login" -> LoginScreen(
                onLogin = { page = "home" },
                onRegister = { page = "register" }
            )
            "register" -> RegisterScreen(
                onCreate = { page = "home" },
                onLogin = { page = "login" }
            )
            "home" -> HomeScreen(
                onProfile = { page = "profile" },
                onSettings = { page = "settings" },
                onLogout = { page = "login" }
            )
            "profile" -> ProfileScreen(onBack = { page = "home" }, onLogout = { page = "login" })
            "settings" -> SettingsScreen(onBack = { page = "home" }, onLogout = { page = "login" })
        }
    }
}

@Composable
fun BrandHeader(compact: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(if (compact) 64.dp else 92.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Blue2, Blue))),
            contentAlignment = Alignment.Center
        ) {
            Text("H", color = Color.White, fontSize = if (compact) 38.sp else 52.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Text("Hussaini App", fontSize = if (compact) 22.sp else 28.sp, fontWeight = FontWeight.Bold, color = Blue)
        Text("Saukin Rayuwa da Fasaha", color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable
fun AuthField(label: String, password: Boolean = false) {
    OutlinedTextField(
        value = "",
        onValueChange = {},
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        leadingIcon = { Icon(if (password) Icons.Default.Lock else Icons.Default.Email, null) }
    )
}

@Composable
fun LoginScreen(onLogin: () -> Unit, onRegister: () -> Unit) {
    Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))
            BrandHeader()
            Spacer(Modifier.height(32.dp))
            Text("Shiga Account", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Ka shiga da bayananka don ci gaba", color = Color.Gray)
            Spacer(Modifier.height(18.dp))
            AuthField("Email ko Phone Number")
            Spacer(Modifier.height(12.dp))
            AuthField("Password", true)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = true, onCheckedChange = {})
                    Text("Remember me", fontSize = 12.sp)
                }
                TextButton(onClick = {}) { Text("Forgot Password?") }
            }
            Button(
                onClick = onLogin,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Login  →", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text("Login with Google")
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ba ka da account? ", color = Color.Gray)
                TextButton(onClick = onRegister) { Text("Create Account") }
            }
        }
    }
}

@Composable
fun RegisterScreen(onCreate: () -> Unit, onLogin: () -> Unit) {
    Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(18.dp))
            BrandHeader(compact = true)
            Spacer(Modifier.height(22.dp))
            Text("Ƙirƙiri Account", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Cika bayanan da ake so don ƙirƙirar account", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            AuthField("Full Name")
            Spacer(Modifier.height(10.dp))
            AuthField("Phone Number ko Email")
            Spacer(Modifier.height(10.dp))
            AuthField("Password", true)
            Spacer(Modifier.height(10.dp))
            AuthField("Confirm Password", true)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Create Account  →", fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ka riga ka da account? ", color = Color.Gray)
                TextButton(onClick = onLogin) { Text("Login") }
            }
        }
    }
}

@Composable
fun HomeScreen(onProfile: () -> Unit, onSettings: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(Blue).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Text("H", color = Blue, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Sannu, Hussaini", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Muna farin cikin ganin ka!", color = Color.White.copy(alpha=.8f), fontSize = 12.sp)
                }
                IconButton(onClick = {}) { Icon(Icons.Default.Notifications, null, tint = Color.White) }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("Sanonni") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") })
                NavigationBarItem(selected = tab == 3, onClick = onProfile, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().background(Bg).padding(16.dp)) {
            OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Nemo abin da kake so...") },
                modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Default.Search, null) })
            Spacer(Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Blue)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("Hussaini App", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Saukin Rayuwa da Fasaha", color = Color.White.copy(alpha=.85f))
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue)) {
                        Text("Fara amfani →")
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Sauran Ayyuka", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Sakonni", Icons.Default.Chat, Modifier.weight(1f)) {}
                HomeAction("Files", Icons.Default.Folder, Modifier.weight(1f)) {}
                HomeAction("Sabis", Icons.Default.Work, Modifier.weight(1f)) {}
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Kudi", Icons.Default.AccountBalanceWallet, Modifier.weight(1f)) {}
                HomeAction("Ilmi", Icons.Default.MenuBook, Modifier.weight(1f)) {}
                HomeAction("Tare da Mu", Icons.Default.People, Modifier.weight(1f)) {}
            }
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Campaign, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Sabon Bayani", fontWeight = FontWeight.Bold)
                        Text("Sabbin abubuwa sun zo!", fontSize = 12.sp, color = Color.Gray)
                    }
                    IconButton(onClick = onSettings) { Icon(Icons.Default.ChevronRight, null) }
                }
            }
        }
    }
}

@Composable
fun HomeAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(92.dp), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, fontSize = 12.sp)
        }
    }
}

@Composable
fun ProfileScreen(onBack: () -> Unit, onLogout: () -> Unit) {
    SimplePage("Profile", onBack) {
        BrandHeader(compact = true)
        Spacer(Modifier.height(16.dp))
        Text("Hussaini General", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("📞 +234 806 123 4567", color = Color.Gray)
        Text("✉️ hussaini@gmail.com", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Text("Edit Profile  →") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Text("Security  →") }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text("Logout")
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onLogout: () -> Unit) {
    var notifications by remember { mutableStateOf(true) }
    var dark by remember { mutableStateOf(false) }
    SimplePage("Settings", onBack) {
        SettingRow("Notifications", "Manage your notifications", notifications) { notifications = it }
        SettingRow("Dark Mode", "Use dark theme", dark) { dark = it }
        Spacer(Modifier.height(8.dp))
        ListItem(headlineContent = { Text("Change Password") }, leadingContent = { Icon(Icons.Default.Lock, null) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) })
        ListItem(headlineContent = { Text("Language") }, supportingContent = { Text("Hausa / English") }, leadingContent = { Icon(Icons.Default.Language, null) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) })
        ListItem(headlineContent = { Text("About App") }, supportingContent = { Text("Version 1.0.0") }, leadingContent = { Icon(Icons.Default.Info, null) })
        Spacer(Modifier.height(16.dp))
        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Logout") }
    }
}

@Composable
fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        leadingContent = { Icon(if (title.contains("Dark")) Icons.Default.DarkMode else Icons.Default.Notifications, null) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) }
    )
}

@Composable
fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(topBar = {
        CenterAlignedTopAppBar(
            title = { Text(title) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().background(Bg).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}
